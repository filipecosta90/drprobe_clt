# produce a two shell CNT with fullerenes inside
# (1) rotate single shells around tube axis and repeat the cell along the tube axis 
CellMuncher --debug  --override --prompt --centre-rotate-axis=y,15 --repeat=y,10  --cif --input-file=CNT_0-18.cel --output-file=CNT_0-18-repy10-croty15.cel
CellMuncher --debug  --override  --centre-rotate-axis=y,5 --repeat=y,10  --cif --input-file=CNT_0-27.cel --output-file=CNT_0-27-repy10-croty15.cel
# (2) merge the shells
CellMuncher  --debug --override  --merge-file=CNT_0-18-repy10-croty15.cel,XMS --cif --input-file=CNT_0-27-repy10-croty15.cel --output-file=two-shell-CNT.cel
# (3) rotate the bucky balls
CellMuncher  --debug  --override  --centre-rotate-axis=x,5 --centre-rotate-axis=y,12  --cif --input-file=C60.cel --output-file=C60_rotA.cel
CellMuncher  --debug  --override  --centre-rotate-axis=x,45 --centre-rotate-axis=z,32  --cif --input-file=C60.cel --output-file=C60_rotB.cel
CellMuncher  --debug  --override  --centre-rotate-axis=x,10 --centre-rotate-axis=y,23 --centre-rotate-axis=z,2  --cif --input-file=C60.cel --output-file=C60_rotC.cel
# (4) fill the tube
CellMuncher  --debug  --override  --merge-file=C60_rotA.cel,XMS,0.5005,0.1,0.501 --merge-file=C60_rotB.cel,XMS,0.5002,0.34,0.498 --merge-file=C60.cel,XMS,0.4982,0.6,0.499 --merge-file=C60_rotC.cel,XMS,0.5001,0.84,0.5001 --cif --input-file=two-shell-CNT.cel --output-file=two-shell-filled-CNT.cel
# (5) change dimensions 
CellMuncher  --debug  --correct-dimension=z --override  --cif --input-file=two-shell-filled-CNT.cel --output-file=tmp.cel
CellMuncher  --debug  --extend-cell-centre=z,1.05 --override  --cif --input-file=tmp.cel --output-file=two-shell-filled-CNT_corrz.cel
# (6) slice
CellMuncher  --debug --cif --delete-duplicate --slice=10 --cif --override  --input-file=two-shell-filled-CNT_corrz.cel --output-file=slice
