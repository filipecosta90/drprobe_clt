# create a wurtzite GaAs nanowire
# repeat hexagonal cell
CellMuncher --repeat=x,2 --repeat=y,5 --repeat=z,5 --override --preview=VESTA --input-file=GaAs_wurtzite_unitcell.cel --output-file=tmp001.cel
# swap axes, preparation for orthogonalisation, only beta can be orthogonalized
CellMuncher --swap-axes=xy --override --preview=VESTA --input-file=tmp001.cel --output-file=tmp002.cel
# orthogonalisation, only beta can be orthogonalized
CellMuncher --orthogonalize-plane=beta,3 --override --preview=VESTA --input-file=tmp002.cel --output-file=tmp003.cel
# repeat in x-direction, make 20 nm thick, y and z are periodic
CellMuncher --debug --delete-duplicate --repeat=x,10  --override --preview=VESTA --input-file=tmp003.cel --output-file=tmp004.cel
# swap axes, so that z is the large dimension and x > y 
CellMuncher --swap-axes=xz --override  --prompt --cif --input-file=tmp004.cel --output-file=GaAs-NW.cel
# delete temporary files
rm tmp???.*
