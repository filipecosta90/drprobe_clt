# roll the dice to create a new site occupancy configuration in AlPdMn
# 
CellMuncher --dice-pair-site-occupancy=Pd,Al,0.5 --dice-pair-site-occupancy=Mn,Al,0.5 --dice-site-occupancy --cif  --input-file=AlPdMn_uc_nodup.cel  --output-file=AlPdMn_uc_dice.cel
