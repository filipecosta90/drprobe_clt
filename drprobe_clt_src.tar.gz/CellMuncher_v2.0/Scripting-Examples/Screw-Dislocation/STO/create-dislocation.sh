# create a screw dislocation in SrTiO3
#
# repeats a SrTiO3 unit cell
# expands the super-cell size
# calculates the screw dislocation displacement including Eshelby twist
#
CellMuncher --cif --repeat=x,10 --repeat=y,10 --repeat=z,10 --input-file=sto_100_simple_uc.cel --output-file=test.cel
CellMuncher --cif --extend-cell-centre=x,1.1 --extend-cell-centre=y,1.1 --extend-cell-centre=z,1.1 --input-file=test.cel --output-file=test2.cel
CellMuncher --cif --screw-dislocation=0.5,0.5,3.9,0. --input-file=test2.cel --output-file=screw-dislocation.cel
CellMuncher --cif --in=screw-dislocation.cel
