# a one-liner:
# create a rectangular block of the Huebnerite mineral in 110 viewing direction
CellMuncher --cif --create-block=1,1,0,0,0,1,3,3,6 --input=MnWO467906.cel --output=MnWO467906-110-super-cell.cel
