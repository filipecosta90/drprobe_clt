#!/usr/bin/perl
use Getopt::Long qw(:config no_ignore_case bundling no_autoabbrev);my $tag = '';	# option variable with default value

$Getopt::Long::autoabbrev=0;
$result=GetOptions ('tag|a=s' => \$tag, 'aba|t=s' => \$tag2);  
if ($tag) {
  print $tag."\n";
  print $tag2."\n";
} else {
  print "notag\n";
};
@opt=(1,2,3,4);
$sizeopt=@opt;
print $sizeopt."\n";
if ($sizeopt > $tag) {
  print $sizeopt." > ".$tag.".\n";
} else {
  print $sizeopt." < ".$tag.".\n";
};
my $st="  0   1.2480  1.9100  1.9100120.0000 90.0000 90.0000";
my @chars=split(//,$st);
$rep=substr($st,0,4);
$a=substr($st,4,8);
$b=substr($st,12,8);
$c=substr($st,20,8);
$al=substr($st,28,8);
$be=substr($st,36,8);
$ga=substr($st,44,8);
print "rep=".$rep."\n";
print "a=".$a."\n";
print "b=".$b."\n";
print "c=".$c."\n";
print "al=".$al."\n";
print "be=".$be."\n";
print "ga=".$ga."\n";
$m=$a*$b;
print "a*be=".$m."\n";
