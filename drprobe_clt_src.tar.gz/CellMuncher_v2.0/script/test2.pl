#!/usr/bin/perl

if ("bl" eq "bla") {$match=1;} else {$match=0};
print "$match"."\n";
