#!/usr/bin/perl
use POSIX qw(ceil floor fmod acos);
use Getopt::Long qw(:config no_ignore_case bundling no_autoabbrev);
use constant false => 0;
use constant true  => 1;
use List::Util 'shuffle';
use File::Basename;
use feature qw/switch/;


sub helphash {
my %hhash = ();
$hhash{'--attach-cell=<value>'}=q{
    attach a super cell file to the input file at the input cell upper face
    <value>-format: s1,s2,s3    
    s1: filename
    s2: XMS,MT,XYZ,JSV
    s3: dimension along which the cell will be attached, i.e. x, y, or z
    --attach-cell=attachme.cel,XMS,x 
    attaches the cell attachme.cel in EMS format to the super cell 
    in the input file, the attached atoms will be placed at the upper face 
    along the x dimension of the input cell
    Note: other cell dimensions have to match};
$hhash{'--align-z-axis-non-periodic=<value> -S <value>'}=q{
    align the z axis to a direction uvw for a periodic object
    <value>-format: f1,f2,f3
    f1,f2,f3: uvw indices
    --align-z-axis-non-periodic=1,2,1
    Aligns the z-axis to the 121 viewing direction.
    Works only for orthogonal lattices!};
$hhash{'--align-z-axis-periodic=<value> -D <value>'}=q{
    Align the z axis to a direction uvw for a periodic object, tries
    to find new period
    <value>-format: f1,f2,f3
    f1,f2,f3: uvw indices
    --align-z-axis-periodic=1,2,1
    Aligns the z-axis to the 121 viewing direction
    Works only for orthogonal lattices! Use the --periodic option to
    fold the cell periodic. Use the --remove-close-atoms option
    to remove close atoms};

$hhash{'--cif'}=q{
    Shortcut for converting an input EMS or XMS file to CIF
    use --input to specifiy input file};

$hhash{'--centre-atoms=<value>'}=q{
    centre atoms within the volume of the unit cell
    s: x,y or z or a combination like  x,y or x,z or x,y,z
    --centre-atoms=x,y
    centre atoms in x and y
    hint: use the --periodic option before!};

$hhash{'--centre-at-zero'}=q{
    centre atoms around the origin (0,0,0) of the coordinate system
    --centre-at-zero
    centre atoms around x=0, y=0, z=0
    hint: use the --periodic option before!};

$hhash{'--centre-rotate-axis=<value> -O <value>'}=q{
    rotate around an axis uvw through the centre of the super-cell
    <value>-format: f1,f2,f3,f4
    f1,f2,f3: uvw indices
    f4: angle in degree
    --centre-rotate-axis=2,1,0,10
    Rotates by 10° around the 210 direction
    the rotation axis goes through centre of the super-cell.
    Works only for orthogonal lattices!};

$hhash{'--correct-dimension=<value> -u <value>'}=q{
    correct unit cell dimensions (deletes vacuum space)
    <value>-format: s
    s: x,y or z or a combination like  x,y or x,z or x,y,z
    --correct-dimension=x,y
    correct dimensions in x and y, after correction, the minimum (maximum) x ynd y
    relative atom coordinate is 0 (1)};

$hhash{'--create-block=<value> -b <value>'}=q{
    repeat a unit cell to an orthogonal block of a certain size and
    with a certain viewing direction
    <value>-format: f1,f2,f3,f4,f5,f6,f7,f8,f9
    f1,f2,f3: x,y,z components of the viewing direction relative to 
              the unit cell axes; this direction will be the new z direction
    f4,f5,f6: x,y,z components relative to the unit cell axes of a
              direction that has an orthogonal component to the viewing direction;
              this direction defines the new b axis of the resulting super-cell
    f7,f8,f9: the dimensions x,y, and z of the new cell in nm
    --create-block=1,1,0,-1,1,0,5,5,3
    create a block with a size of 5x5x3 nm3 and a z-direction that
    corresponds to 110, the new y-direction is parallel to -1,1,0};

$hhash{'--cut-above=<value> -c <value>'}=q{
    cut along one direction above a certain value
    <value>-format: s1,f [,s2]
    s1: x or y
    f: cut coordinate [or atom index]
    s2: index, indicates that f is the number of atom from where to
    cut (optional)
    --cut-above=x,0.7
    cut all atoms with x > 0 .7
    --cut-above=x,123,index
    cut all atoms with index > 123 in the list sorted for x};
 
$hhash{'--cut-above-plane=<value> -a <value>'}=q{
    cut atoms above a certain plane in a distance  from the origin
    <value>-format: f1,f2,f3,f4 
    f1,f2,f3: plane indices
    f4: distance from origin in Angstrom
    --cut-above-plane=1,1,1,25
    cut all atoms above the 111-plane in a distance of 25 Angstrom};

$hhash{'--cut-at-distance=<value>'}=q{
    cut atoms beyond a certain distance  from the origin
    <value>-format: s,f 
    s: axis, x,y or z or xy,yz or xz or xyz
    f: distance from origin in Angstrom
    --cut-at-distance=xy,25
    cut a cylinder with the z-axis as the cylinder axis and a radius
    of 25 Angstrom
    --cut-at-distance=xyz,25
    cut a sphere with a radius of 25 Angstrom
    Note: Only for orthogonal lattices};

$hhash{'--cut-below=<value> -C <value>'}=q{
    cut along one direction below  a certain value
    <value>-format: s1,f [,s2]
    s1: x or y
    f: cut coordinate [or atom index]
    s2: index, indicates that f is the number of atom from where to
    cut (optional)
    --cut-below=x,0.3
    cut all atoms with x < 0 .3
    --cut-below=x,12,index
    cut all atoms with index < 12 in the list sorted for x};

$hhash{'--cut-below-distance=<value>'}=q{
    cut atoms below a certain distance  from the origin
    <value>-format: s,f 
    s: axis, x,y or z or xy,yz or xz or xyz
    f: distance from origin in Angstrom
    --cut-below-distance=xyz,15
    cut atoms within a a sphere with a radius of 15 Angstrom
    Note: Only for orthogonal lattices};

$hhash{'--cut-below-plane=<value> -A <value>'}=q{
    cut atoms below a certain plane in a distance  from the origin
    <value>-format: f1,f2,f3,f4 
    f1,f2,f3: plane indices
    f4: distance from origin in Angstrom
    --cut-below-plane=-1,-1,-1,25
    cut all atoms below the 111-plane in a distance of 25 Angstrom};

$hhash{'--cut-cell-dimension=<value>'}=q{
    cut cell along one direction below and above a certain relative coordinate
    <value>-format: s1,f1,f2
    s1: x or y or z
    f1, f2: relative cut coordinate, lower bound and upper bound
    --cut-cell-dimension=x,0.2,0.8
    cut all atoms with x < 0 .2 and x > 0.8 and correct unit cell dimension};

$hhash{'--decorate=<value>'}=q{
    decorates the positions in a super cell with a point group 
    from a file	
    <value>-format: s1,s2[,s3]    
    s1: filename
    s2: XMS,MT,XYZ,JSV
    s3: orientation, optional values: "rndrot"
    --decorate=molecule.cel,XMS,rndrot
    decorates all the positions in the input file with the molecule
    data in molecule.cel. The molecule will be rotated in a random 
    fashion. Note that the centre of the molecule in molecule.cel  
    should be at 0,0,0. };

$hhash{'--debug'}=q{
    switch on debugging code
    --debug};

$hhash{'--delete-duplicate|unique|-d'}=q{
    delete duplicate atom
    --delete-duplicate
    delete duplicate atoms in the list};

$hhash{'--delete-element=<value> -Y <value>'}=q{
    delete an element from the list
    <value>-format: s
    s: element symbol
    --delete-element=Mo
   delete all molybdenum atoms from the list};

$hhash{'--dice-pair-site-occupancy=<value>'}=q{
    create a specific site occupancy configuration for a site that may
    be occupied by two elements A and B
    <value>-format: s1,s2,f
    s1: element symbol for A
    s2: element symbol for B 
    f: maximum distance between A and B sites in Angstrom
    --dice-pair-site-occupancy=Pd,Al,0.4
    for each of the Pd and Al sites that are closer than 0.4 Å:
    set the occupancy of the Pd atom to 1 with a probability, 
    that corresponds to the occupancy on that site, the occupancy
    of Al is set to 0 if the site is occupied by Pd and 1 otherwise
    note that vacant sites are deleted from the atom list!};

$hhash{'--dice-site-occupancy'}=q{
    create a specific site occupancy configuration
    --dice-site-occupancy
    set the occupancy for each atom site to 1 or 0
    the probability for site occupation  corresponds to the
    occupancy parameter, note that occupancies are either 1 or 0
    afterwards, vacant sites are deleted from the atom list!};

$hhash{'--extend-cell=<value> -e <value>'}=q{
    extend unit cell without translating elements
    <value>-format: s,f 
    s: axis, x,y or z
    f: scaling factor
    --extend-cell=x,1.15
    extends the unit cell along x by a factor of 1.15};

$hhash{'--extend-cell-centre=<value> -E <value>'}=q{
    extend unit cell, translate atoms so that the old cell is centred
    in the new cell
    <value>-format: s,f 
    s: axis, x,y or z
    f: scaling factor
    --extend-cell-centre=y,1.2
    extends the unit cell along y by a factor of 1.2, then translates
    along y by 0.1};

$hhash{'--expand-structure=<value>'}=q{
    expand a non-periodic structure e.g. a nanoparticle by a factor f 
    <value>-format: f
    f: factor
    --expand-structure=1.05
    expands a structure by 5 % };

$hhash{'--extend-to-size=<value>'}=q{
    extend unit cell to a certain size in Ångstrom, translate atoms so 
    that the old cell is centred in the new cell
    <value>-format: s,f 
    s: axis, x,y or z f: size in Å
    --extend-to-size=z,100
    extends the unit cell along z to a size of 100 Ångstrom and
    translates the atoms into the centre around z=50 Ångstrom};

$hhash{'--frozen-lattice=<value> -F <value>'}=q{
    generate a frozen lattice configuration
    <value>-format: s
    s: x,y or z or a combination like  x,y or x,z or x,y,z
    --frozen-lattice=x,y
    create a frozen lattice configuration
    takes for each atom the DW factor and creates a random displacement in x,y 
    displacements along one crystallographic direction follow a normal
    distribution with standard deviation Sqrt(1/(3*8Pi^2)*DW) and are
    usually about 4-6 pm on average};

$hhash{'--frozen-lattice-fix-margin=<value>'}=q{
    generate a frozen lattice configuration, keep atoms at the
    boundary fixed
    <value>-format: s,f1,f2,f3
    s: x,y or z 
    f1,f2,f3: margin width in x,y and z respectively in relative supercell size
    --frozen-lattice-fix-margin=x,0.1,0.2,0.0
    create a frozen lattice configuration for atoms in 0.1 <= x <= 0.9 and 0.2 <= y <= 0.8 and 0 <= z <=1 
    takes for each atom the DW factor and creates a random
    displacement in x,y  displacements along one crystallographic
    direction follow  a normal distribution with standard deviation 
    Sqrt(1/(3*8Pi^2)*DW) and are usually about 4-6 pm on average};
    
$hhash{'--help'}=q{
    display a help page
    --help};
   
$hhash{'--input-file=<value> --input=<value> -f <value>'}=q{
    file name of the input super-cell
    <value>-format: s
    s: filename
    --input-file=mycell.cel
    input data will be read from mycell.cel};

$hhash{'--invert-axis=<value> -I <value>'}=q{
    invert atom positions on an axis	
    <value>-format: s
    s: x,y or z
    --invert-axis=z
    Invert atom positions on the z-axis};

$hhash{'--merge-file=<value> -H <value>'}=q{
    merges a super cell file to the input file	
    <value>-format: s1,s2[,f1,f2,f3]    
    s1:filename
    s2:XMS,MT,XYZ,JSV
    f1,f2,f3: position in relative coordinates, optional
    --merge-file=mymerge.cel,XMS 
    merges the cell mymerge,cel in EMS format to the super cell 
    in the input file,the merged atoms will be centred in the middle of
    the cell
    --merge-file=mymerge.cel,XMS,0.2,0.3,0.6
    same, but the atoms in mymerge.cel will be centred around the
    relative position 0.2,0.3,0.6
    Note: so far the cell of the merge file needs to be smaller than 
    the cell of the input file};

$hhash{'--mirror-atom=<value> -m <value>'}=q{
    mirror single atom on an axis
    <value>-format: s,i,f
    s: x,y or z
    i: atom index
    f: mirror position in relative coordinates
    --mirror-atom=y,121,0.6
    Mirror atom 121 on the y-axis, mirror point is the relative
    coordinate 0.6};

$hhash{'--mirror-axis=<value> -M <value>'}=q{
    mirror atom positions on an axis
    <value>-format: s,f
    s: x,y or z
    f: mirror position in relative coordinates
    --mirror-axis=x,0.3
    Mirror atom positions on the x-axis, mirror point is the relative
    coordinate 0.3};

$hhash{'--orthogonalize-plane=<value> -g <value>'}=q{	
    orthogonalize a  plane with non-orthogonal base vectors
    <value>-format: s,i
    s: xy, xz or yz
    i: maximum increase in cell volume
    --orthogonalize-plane=xz,10
    Orthogonalize xz-plane, maximum increase in cell volume is 10. The
    algorithm tries to find a new periodic supercell.
    Works only for xz so far (where beta is not 90°), xy and yz are not implemented!
    Note: it depends on the angle and base vector lengths whether a
    solution can be found. The program will stop if there is no exact
    solution within the given bound. In that case it is better to
    create a non-periodic orthogonal cell using the --create-block
    option.};

$hhash{'--output-file=<value> --output=<value> -o <value>'}=q{
   file name of the output super-cell
   <value>-format: s
   s: filename
   -—write-format=XMS,CIF -—output-file=my2ndcell
   output data will be written to from my2ndcell.cel and my2ndcell.cif
   if not given, then CellMuncher will try to construct the output filename from
   the input filename, i.e. a file conversion from EMS to MacTempas format will
   work with the two options
   -—write-format=MT -—input=mycell.cel
   to produce mycell.at};

$hhash{'--override'}=q{
    don’t ask if output-file exists, just override it
    --override};

$hhash{'--periodic=<value> -p <value>'}=q{
    fold periodic
    <value>-format: s
    s: x or y or z
    --periodic=x
    fold x axis periodic, that means all relative x-coordinates will
    be translated to the interval [0,1[, presuming that the structure
    is periodic};

$hhash{'--point-defect-displacements=<value>'}=q{
  calculate an exponentially decaying displacement with the distance around a given centre,
  including a cosine modulation of the radial displacement  
  <value>: f1,f2,f3,f4,f5,f6,f7,f8
  f1: point defect centre x, relative coordinates
  f2: point defect centre y, relative coordinates
  f3: point defect centre z, relative coordinates
  f4: displacement amplitude (A)
  f5: sigma width (A)
  f6: cosine fraction, fraction of f1 as a relative number
      between 0 and 1 
  f7: cosine period width (A)
  f8: cut-off radius (A)};

$hhash{'--preview=<value>'}=q{
    generate a preview file and display the preview in CrystalMaker, Vesta or Safari
    (Mac OS X and Linux so far)
    <value>-format: s
    s: CM or VESTA or Safari
    --preview=VESTA
    sends CIF output to Vesta, choose CM for CrystalMaker preview and Safari for a Safari preview};

$hhash{'--prompt'}=q{
    wait for user input after each preview output
    --prompt};

$hhash{'--read-format=<value> -r=<value>'}=q{
    file format of the input super-cell
    <value>-format: s
    s: format where format is
    XMS=EMS format 
    MT=MacTempas format
    XYZ=Ascii format
    --read-format=XMS
    input data is an EMS data file
    XYZ ascii data file format: 
    line #1: comment line
    line #2: a b c alpha beta gamma
    line #3: number of atoms N
    line #4: Atom Symbol X Y Z
    line #N+3: - "" - 
    X,Y, and Z are in absolute coordinates (Angstrom)};

$hhash{'--repeat=<value> -j <value>'}=q{	
    repeat the super cell along one direction
    <value>-format: s,i
    s: direction: x,y or z
    i: integer factor
    --repeat=x,2
   repeat the super cell 2 times along x};

$hhash{'--repeat-to-size=<value>'}=q{
    scale the super cell along one direction to a certain size in
    Ångstrom and fill with atoms
    <value>-format: s,f
    s: direction: x,y or z
    f: size in Ångstrom
    --repeat-to-size=x,200
    scale the super cell in x-direction to 200 Ångstrom};

$hhash{'--replace=<value>'}=q{
    replace an element with another element
    <value>-format: s,s 
    s,s: element symbols
    --replace=Ga,In
    replace Ga with In};

$hhash{'--remove-close-atoms=<value> -v <value>'}=q{
    removes atoms that are closer than a certain distance to an atom that appeared earlier 
    in the list
    <value>-format: f
    f: distance in Angstrom
    --remove-close-atoms=0.8
    removes atoms that are closer than 0.8 Angstrom: the atom
    with the lower index in the list will remain, use together with
    the --sort, --shuffle, --reverse options to re-arrange the list
    and determine which atom or element will be first and remain};

$hhash{'--reverse'}=q{
    put atom list in reverse order
    --sort=x --reverse
    first sort according to ascending x-coordinate, then reverse output};

$hhash{'--rotate-axis=<value> -R <value>'}=q{
    rotate around an axis uvw through 0,0,0
    <value>-format: f1,f2,f3,f4
    f1,f2,f3: uvw indices f4: angle in degree
    --rotate-axis=2,1,0,10
    Rotates by 10° around the 210 direction, 
    the rotation axis goes through the 000 corner of the super-cell.
    Works only for orthogonal lattices!};

$hhash{'--rotate-non-periodic=<value> -Q <value>'}=q{
    rotate a non-periodic object around an axis uvw through the centre
    of a super-cell	
    <value>-format: f1,f2,f3,f4
    f1,f2,f3: uvw indices
    f4: angle in degree
    --rotate-non-periodic=1,2,2,14
    Rotates by 14° around the 122 direction, the rotation axis goes
    through the centre of the super-cell. Works only for orthogonal lattices!};

$hhash{'--slice=<value> -L <value>'}=q{
    slice the super-cell in z direction
    <value>-format: i
    i: number of slices
    --slice=10
    create 10 slices in z direction with the thickness dz=0.1 in
    relative coordinates slices are labelled by a running counter starting from 001
    specify only the prefix for the output, e.g. -o slc will lead to
    the output of slc001.cel, slc002.cel ... for --output-format=XMS
    or the output of slc001.at, slc002.at ... for --output-format=MT
    or the output of slc001.cif, slc002.cif ... for --output-format=CIF};

$hhash{'--slice-by-list=<value> -L <value>'}=q{
    slice the super-cell in z direction at given values
    <value>-format: f1,f2,f3,...
    f1,f2,f3, ... : comma separated list of relative coordinates for the slice cut
    --slice=0.1,0.3,0.8
    create 4 slices in z direction
    slices are labelled by a running counter starting from 001
    specify only the prefix for the output, e.g. -o slc will lead to
    the output of slc001.cel, slc002.cel ... for --output-format=XMS
    or the output of slc001.at, slc002.at ... for --output-format=MT
    or the output of slc001.cif, slc002.cif ... for --output-format=CIF};

$hhash{'--screw-dislocation=<value>'}=q{
    create a displacement field of a srew islocation, including
    Eshelby twist
    <value>-format: f1,f2,f3
    f1,f2: x,y position in relative coordinates
    f3:magnitude of Burgers vector in Ångstrom
    --screw-dislocation=0.5,0.5,1.5
    creates a screw dislocation in the centre of the super cell
    the Burgers vector has a magnitude of +1.5 Angstrom
    atoms are shifted according to the eshelby equation 
    hint: expand unit cell before in order to avoid wrap arounds};	

$hhash{'--set-dw-factor=<value> -B <value>'}=q{
    set the Debye-Waller factor for one element
    <value>-format: s,f 
    s,f: element symbol, DW factor in nm2
    --set-dw-factor=Sr,0.0046
    set the Debye-Waller factor of strontium atoms to 0.0046 nm2,
    the DW factor corresponds to 8*pi^2*u^2 where u^2 is the 
    isotropic mean quadratic displacement};

$hhash{'--set-occupancy=<value>'}=q{
    set the site occupancy for one element
    <value>-format: s,f 
    s,f: element symbol, site occupancy
    --set-occupancy=Ga,0.6
    set the site occupancy of gallium atoms to 0.6};

$hhash{'--shuffle'}=q{
    shuffle the atom list };

$hhash{'--sort=<value> -s <value>'}=q{
    <value>-format: s
    s: x, y, z, e, all
    --sort=x --sort=e
    first sort according to the x-coordinate then according to the
    element};

$hhash{'--swap-axes=<value> -x <value>'}=q{
    swap two axes
    <value>-format: s
    s: xy or xz or   yz
    --swap-axes=xy
    swap x- with y-axis};

$hhash{'--translate-atom=<value> -t <value>'}=q{
    translate single atom on an axis
    <value>-format: s,i,f
    s: x,y or z
    i: atom index
    f: translation in relative coordinates
    --translate-atom=z,12,0.1
    Translate atom 12 on the z-axis by 0.1 relative to the z-dimension of the unit cell. };

$hhash{'--translate-axis=<value> -T <value>'}=q{
    tranlate atom positions on an axis
    <value>-format: s,f
    s: x,y or z
    f: translation in relative coordinates
    --translate-axis=x,0.3
    Translate all the atoms on the x-axis by value 0.3 in relative coordinates};

$hhash{'--unformatted'}=q{
    write unformatted output in combination with EMS or XMS output };

$hhash{'--wedge-cut-above=<value> -k <value>'}=q{
    cut a wedge from the top of the super cell
    <value>-format: s1,f1,f2
    s1: x or y
    f1: angle in degree
    f2: offset in relative coordinates
    an atom is removed, when  z > s1*tan(f1) + f2
    --wedge-cut-above=y,30,0
    create a 30°-wedge in the yz-plane, top part of the cell is vacuum};

$hhash{'--wedge-cut-below=<value> -K <value>'}=q{
    cut a wedge from the bottom of  the super cell
    <value>-format: s1,f1,f2
    s1: x or y
    f1: angle in degree
    f2: offset in relative coordinates
    an atom is removed, when  z < s1*tan(f1) + f2
    --wedge-cut-below=x,30,0
    create a 30°-wedge in the xz-plane, bottom part of the cell is vacuum};

$hhash{'--write-format=<value> -w=<value>'}=q{
    file format of the output super-cell
    <value>-format: s1[,s2[,s3[,…]]]
    s1, s2, s3, ...: format where format is 
    XMS=EMS format (enhanced precsion 10F6, if --unformatted is not set)
    EMS=EMS format (standard precision 8F4, if --unformatted is not set)
    MT=MacTempas format
    CIF=CIF  format
    VESTA=for Vesta structure viewer, identical with CIF format
    CM=Crystal Maker text format
    ALI=Crystal Maker text format
    JSV=JSV structure viewer format
    WRL=VRML  format
    --write-format=XMS
    output data is an EMS data file with enhanced accuracy 
    (10F6 instead of 8F4 for the atom positions)
    —write-format=CIF,XMS,MT
    output data is in CIF, EMS and MacTempas format};

return \%hhash;
};

my $myhelphash_ref=helphash();
my %myhelphash=%$myhelphash_ref;


# parse options
$Getopt::Long::autoabbrev=0;
$help="";
$inputfile="";
$outputfile="";
$result = Getopt::Long::GetOptions ("help|h" => \$help, 
				    "searchcommand=s" => \$searchcommand,
				    "searchhelp=s" => \$searchhelp);
if ($help) {
  print "$_ $myhelphash{$_}\n\n" for (keys %myhelphash);
  print "Did you already try --serchcommand=<value> or --searchhelp=<value>?.\n\n";
};

if ($searchcommand) {
  my $searchme=quotemeta lc $searchcommand;
  my $matches=0;
  my $lastmatch="";
 # print "\n";
  foreach $keys (keys %myhelphash) {
    #print $keys." ".$searchme."\n";
    if ($keys =~ m/$searchme/g) {
      print $keys."\n";
      $matches += 1;
      $lastmatch=$keys;
      #print $keys $myhelphash{$keys};
    };
  };
  if ($matches == 0) {
    die "No matches, try to re-run the search command with another search string.\n"
  };
  if ($matches == 1) {
    print $myhelphash{$lastmatch};
    print "\n";
    die "\n"; 
  } else {
    die "Multiple matches, re-run command with a slightly extended search string to display the unique solution.\n"; 
  }
};

if ($searchhelp) {
  my $searchme=quotemeta lc $searchhelp;
  my $matches=0;
  my $lastmatch="";
 # print "\n";
  foreach $keys (keys %myhelphash) {
    # print $myhelphash{$keys}." <=> ".$searchme."\n";
    if ($myhelphash{$keys} =~ m/$searchme/g) {
      print $keys."\n";
      $matches += 1;
      $lastmatch=$keys;
      #print $keys $myhelphash{$keys};
    };
  };
  if ($matches == 0) {
    die "No matches, try to re-run the help search command with another search string.\n"
  };
  if ($matches == 1) {
    print $myhelphash{$lastmatch};
    print "\n";
    die "\n"; 
  } else {
    die "Multiple matches, re-run the help search command with a slightly extended search string to display the unique solution.\n"; 
  }
};
