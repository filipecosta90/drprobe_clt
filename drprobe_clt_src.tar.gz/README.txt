Dr. Probe command-line tool project (drprobe_clt)

by Juri Barthel
   Forschungszentrum J�lich GmbH, 52425 J�lich, Germany

Copyright (c) 2008 - 2018 - Forschungszentrum J�lich GmbH

Published under the GNU General Public License, version 3,
see <http://www.gnu.org/licenses/> and LICENSE.txt!


This project contains the following programs:

1) CELSLC

CELSLC is a program to calculate object transmission functions to be used
as phase gratings in a multislice algorithm for electron diffraction
calculations. The calculations require an atomic structure model as input,
including the definition of a calculation box, atomic coordinates,
thermal vibration parameters, and partial occupancy factors. Further
parameters concern numerical sampling and the probing electron energy. The
output produced can be used as input of the program MSA.

2) MSA

MSA is a program to calculate the diffraction of beam of probing electrons
through a crystal. The crystal data is input in form of phase gratings or
projected scattering potentials as calculated by the program CELSLC. Further
parameters concern the probe forming, sample thickness, scan settings etc.
Output are electron wave functions or STEM images.

3) WAVIMG

WAVIMG is a program used for the calculation of high-reslolution TEM images
from an input electron wave function. 


The programs are written in Fortran 90 code for Intel Fortran compilers.

